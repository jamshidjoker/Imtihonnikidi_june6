package com.pdp_dars.imtihonnikidi.utils

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences

class SharedPref(context: Context) {

    private var preferences: SharedPreferences =
        context.getSharedPreferences("APP_PREFS_NAME", MODE_PRIVATE)

    private lateinit var editor: SharedPreferences.Editor

    fun setUserName(name:String){
        editor = preferences.edit()
        editor.putString("USERNAME", name)
        editor.apply()
    }
    fun getUserName() = preferences.getString("USERNAME","")
    fun setLock(lock:String){
        editor = preferences.edit()
        editor.putString("LOCK",lock)
        editor.apply()
    }
    fun getLock()=preferences.getString("LOCK","")
    fun setOpen(open:String){
        editor = preferences.edit()
        editor.putString("OPEN",open)
        editor.apply()
    }
    fun getOpen() = preferences.getString("OPEN","LOGIN")
    fun setToken(token: String) {
        editor = preferences.edit()
        editor.putString("TOKEN", token)
        editor.apply()
    }

    fun getToken() = preferences.getString("TOKEN", "")

    fun setName(name:String){
        editor = preferences.edit()
        editor.putString("NAME", name)
        editor.apply()
    }
    fun getName() = preferences.getString("NAME","")
    fun setEmail(email:String){
        editor = preferences.edit()
        editor.putString("EMAIL",email)
        editor.apply()
    }
    fun setSignUp(issignUp:String){
        editor = preferences.edit()
        editor.putString("ISSIGNUP", issignUp)
        editor.apply()
    }
    fun getSignUp() = preferences.getString("ISSIGNUP","FALSE")
    fun setsignUpResponceCode(code:String){
        editor = preferences.edit()
        editor.putString("CODE", code)
        editor.apply()
    }
    fun getSignUpResponceCode() = preferences.getString("CODE", "NOCODE")
    fun getEmail() = preferences.getString("EMAIL","")
}