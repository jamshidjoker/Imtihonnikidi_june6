package com.pdp_dars.imtihonnikidi.retrofit

import com.pdp_dars.imtihonnikidi.retrofit.requestes.LogInRequest
import com.pdp_dars.imtihonnikidi.retrofit.requestes.SignUpRequest
import com.pdp_dars.imtihonnikidi.retrofit.responces.LogInResponse
import com.pdp_dars.imtihonnikidi.retrofit.responces.SignUpResponse
import com.pdp_dars.imtihonnikidi.retrofit.requestes.TrainerRequest
import com.pdp_dars.imtihonnikidi.retrofit.responces.TrainerResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("trainer_with_role")
    fun getTrainersList(): Call<List<TrainerResponse>>

    @POST("trainer_with_role")
    fun addTrainer(@Body trainer: TrainerRequest): Call<TrainerResponse>

    @DELETE("trainer_with_role/{id}")
    fun deleteTrainer(@Path("id") id: Int): Call<TrainerResponse>

    @PUT("trainer_with_role/{id}")
    fun editTrainer(
        @Body trainer: TrainerRequest,
        @Path("id") id: Int
    ): Call<TrainerResponse>

    @POST("auth/signin")
    fun logIn(@Body login: LogInRequest): Call<LogInResponse>

    @POST("auth/signup")
    fun signUp(@Body signup: SignUpRequest):Call<SignUpResponse>
}