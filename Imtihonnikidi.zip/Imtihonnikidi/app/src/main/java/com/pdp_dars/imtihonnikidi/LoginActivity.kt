package com.pdp_dars.imtihonnikidi

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.pdp_dars.imtihonnikidi.databinding.ActivityLogin2Binding
import com.pdp_dars.imtihonnikidi.utils.SharedPref

class LoginActivity : AppCompatActivity() {
    lateinit var binding:ActivityLogin2Binding
    val shared by lazy{
        SharedPref(this)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogin2Binding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.login.setOnClickListener {
            shared.setUserName(binding.username.text.toString())
            shared.setLock(binding.password.text.toString())
            shared.setOpen("LOGIN")
            startActivity(Intent(this@LoginActivity, ResultActivity::class.java))
        }
    }
}