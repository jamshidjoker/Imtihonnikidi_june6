package com.pdp_dars.imtihonnikidi.retrofit.requestes

data class TrainerRequest(
    var trainerName: String,
    var trainerSalary: Double,
    var trainerSurname: String
)