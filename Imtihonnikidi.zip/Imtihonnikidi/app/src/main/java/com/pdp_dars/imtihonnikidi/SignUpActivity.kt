package com.pdp_dars.imtihonnikidi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.pdp_dars.imtihonnikidi.databinding.ActivitySignUpBinding
import com.pdp_dars.imtihonnikidi.utils.SharedPref

class SignUpActivity : AppCompatActivity() {
    lateinit var binding:ActivitySignUpBinding
    val shared by lazy {
        SharedPref(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.signUP.setOnClickListener {
            shared.setName(binding.name.text.toString())
            shared.setLock(binding.password.text.toString())
            shared.setOpen("SIGNUP")
            shared.setEmail(binding.email.text.toString())
            shared.setUserName(binding.userName.text.toString())
            shared.setsignUpResponceCode("NONE")
            if (binding.email.text.isNotEmpty() || binding.name.text.isNotEmpty() || binding.userName.text.isNotEmpty()|| binding.password.text.isNotEmpty()){
                startActivity(Intent(this,ResultActivity::class.java))
            }else{
                Toast.makeText(this, "Ma'lumotlarni to'ldiring", Toast.LENGTH_SHORT).show()
            }

        }
    }
}