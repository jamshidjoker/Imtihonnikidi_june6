package com.pdp_dars.imtihonnikidi.di.module

import com.pdp_dars.imtihonnikidi.LoginActivity
import com.pdp_dars.imtihonnikidi.MainActivity
import com.pdp_dars.imtihonnikidi.ResultActivity
import com.pdp_dars.imtihonnikidi.SignUpActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityBuildersModule {
    @ContributesAndroidInjector()
    abstract fun contributeLoginActivity():ResultActivity

}