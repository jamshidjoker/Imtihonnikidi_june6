package com.pdp_dars.imtihonnikidi.mvvm

import androidx.lifecycle.ViewModel

class ActivityViewModel :ViewModel(){

}