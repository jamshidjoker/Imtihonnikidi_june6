package com.pdp_dars.imtihonnikidi.retrofit.responces

import com.google.gson.annotations.SerializedName

data class LogInResponse(
    @SerializedName("accessToken")
    var accessToken: String,
    @SerializedName("tokenType")
    var tokenType: String
)