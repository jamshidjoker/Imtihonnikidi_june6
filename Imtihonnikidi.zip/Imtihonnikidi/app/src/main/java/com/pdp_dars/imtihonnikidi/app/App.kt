package com.pdp_dars.imtihonnikidi.app

import com.pdp_dars.imtihonnikidi.di.component.AppComponent
import com.pdp_dars.imtihonnikidi.di.component.DaggerAppComponent
import dagger.android.DaggerApplication

class App: DaggerApplication() {
    override fun applicationInjector(): AppComponent {
        return DaggerAppComponent.builder().application(this).build()
    }
}