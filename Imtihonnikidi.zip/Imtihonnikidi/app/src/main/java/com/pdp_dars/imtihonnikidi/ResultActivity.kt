package com.pdp_dars.imtihonnikidi

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.pdp_dars.imtihonnikidi.retrofit.requestes.LogInRequest
import com.pdp_dars.imtihonnikidi.retrofit.requestes.SignUpRequest
import com.pdp_dars.imtihonnikidi.retrofit.responces.LogInResponse
import com.pdp_dars.imtihonnikidi.retrofit.responces.SignUpResponse
import com.pdp_dars.imtihonnikidi.adapter.TrainerAdapter
import com.pdp_dars.imtihonnikidi.databinding.ActivityResultBinding
import com.pdp_dars.imtihonnikidi.retrofit.ApiService
import com.pdp_dars.imtihonnikidi.retrofit.responces.TrainerResponse
import com.pdp_dars.imtihonnikidi.utils.SharedPref
import dagger.android.support.DaggerAppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject

class ResultActivity : DaggerAppCompatActivity() {
    @Inject
    lateinit var sharedPref: SharedPref

    @Inject
    lateinit var apiService: ApiService

    lateinit var binding: ActivityResultBinding

    lateinit var adapter: TrainerAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        adapter = TrainerAdapter()
        binding.list.layoutManager = LinearLayoutManager(this)
        binding.list.adapter = adapter

        if (sharedPref.getOpen().toString() == "SIGNUP") {
            val role = listOf("ROLE_USER")
            funSingUp(
                SignUpRequest(
                    sharedPref.getName().toString(),
                    sharedPref.getUserName().toString(),
                    sharedPref.getEmail().toString(),
                    role,
                    sharedPref.getLock().toString()
                )
            )

//            apiService.getTrainersList()
//                .enqueue(object : Callback<List<TrainerResponse>> {
//                    override fun onResponse(
//                        call: Call<List<TrainerResponse>>,
//                        response: Response<List<TrainerResponse>>
//                    ) {
//                        if (response.isSuccessful) {
//                            response.body()?.let { it ->
//                                adapter.setAllData(it)
//                            }
//                        }
//                    }
//                    override fun onFailure(
//                        call: Call<List<TrainerResponse>>,
//                        t: Throwable
//                    ) {
//
//                    }
//
//                })

        } else if (sharedPref.getOpen().toString() == "LOGIN") {
            funSignIn()
        }
    }
    ////login
    private fun funSignIn(){
        apiService.logIn(
            LogInRequest(
                sharedPref.getUserName().toString(),
                sharedPref.getLock().toString()
            )
        )
            .enqueue(object : Callback<LogInResponse> {
                override fun onResponse(
                    call: Call<LogInResponse>,
                    response: Response<LogInResponse>
                ) {
                    if (response.code() == 200) {
                        response.body()?.let {
                            sharedPref.setToken(it.accessToken)
                            apiService.getTrainersList()
                                .enqueue(object : Callback<List<TrainerResponse>> {
                                    override fun onResponse(
                                        call: Call<List<TrainerResponse>>,
                                        response: Response<List<TrainerResponse>>
                                    ) {
                                        if (response.isSuccessful) {
                                            response.body()?.let { it ->
                                                adapter.setAllData(it)
                                            }
                                        }
                                    }
                                    override fun onFailure(
                                        call: Call<List<TrainerResponse>>,
                                        t: Throwable
                                    ) {

                                    }

                                })
                        }

                    }
                }

                override fun onFailure(call: Call<LogInResponse>, t: Throwable) {

                }
            })
    }


    ///signUp


    private fun funSingUp(signUpRequest: SignUpRequest){
        apiService.signUp(signUpRequest).enqueue(object : Callback<SignUpResponse> {
            override fun onResponse(
                call: Call<SignUpResponse>,
                response: Response<SignUpResponse>
            ) {
                Log.d("SSSSSS", "onFailure: WON")
                sharedPref.setsignUpResponceCode(response.code().toString())
                if (response.code() == 200) {
                    response.body()?.let {
                        apiService.getTrainersList()
                            .enqueue(object : Callback<List<TrainerResponse>> {
                                override fun onResponse(
                                    call: Call<List<TrainerResponse>>,
                                    response: Response<List<TrainerResponse>>
                                ) {
                                    if (response.isSuccessful) {
                                        response.body()?.let { it ->
                                            adapter.setAllData(it)
                                        }
                                    }
                                }
                                override fun onFailure(
                                    call: Call<List<TrainerResponse>>,
                                    t: Throwable
                                ) {

                                }

                            })
                    }
                }
            }

            override fun onFailure(call: Call<SignUpResponse>, t: Throwable) {
                Log.d("SSSSSS", "onFailure: ${t.message}")
            }

        })
        Thread.sleep(2000)
        Toast.makeText(this, "tugadi", Toast.LENGTH_SHORT).show()
        funSignIn()
    }
}