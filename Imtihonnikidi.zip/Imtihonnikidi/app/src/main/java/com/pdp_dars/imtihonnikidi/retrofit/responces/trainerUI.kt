package com.pdp_dars.imtihonnikidi.retrofit.responces

data class trainerUI (var trainerName: String, var salary: Double, var trainerSurnameX: String)