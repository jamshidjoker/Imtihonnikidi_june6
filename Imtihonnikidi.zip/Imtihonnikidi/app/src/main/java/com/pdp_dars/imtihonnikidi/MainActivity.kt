package com.pdp_dars.imtihonnikidi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.pdp_dars.imtihonnikidi.controller.extention
import com.pdp_dars.imtihonnikidi.databinding.ActivityMainBinding
import com.pdp_dars.imtihonnikidi.retrofit.ApiService
import com.pdp_dars.imtihonnikidi.utils.SharedPref
import dagger.android.support.DaggerAppCompatActivity
import javax.inject.Inject

class MainActivity :AppCompatActivity() {
    lateinit var binding:ActivityMainBinding
    @Inject
    lateinit var sharedPref: SharedPref
    @Inject
    lateinit var apiService: ApiService
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        extention.init(R.id.controller,supportFragmentManager)
//        extention.controller?.startMainFragment(TrainerFragment())

            binding.signUp.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }
        binding.signIn.setOnClickListener {

            startActivity(Intent(this, LoginActivity::class.java))
        }
    }
}