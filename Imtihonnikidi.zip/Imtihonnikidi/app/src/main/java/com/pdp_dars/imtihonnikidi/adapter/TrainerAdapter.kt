package com.pdp_dars.imtihonnikidi.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.pdp_dars.imtihonnikidi.databinding.ItemTrainerBinding
import com.pdp_dars.imtihonnikidi.retrofit.responces.TrainerResponse

class TrainerAdapter: RecyclerView.Adapter<TrainerAdapter.TrainerViewHolder>() {
    val data = ArrayList<TrainerResponse>()
    @SuppressLint("NotifyDataSetChanged")
    fun setAllData(data1: List<TrainerResponse>){
        this.data.clear()
        this.data.addAll(data1)
        notifyDataSetChanged()
    }
    inner class TrainerViewHolder(var binding: ItemTrainerBinding): RecyclerView.ViewHolder(binding.root){
        fun bindData(tdata:TrainerResponse){
            binding.userName.text=tdata.trainerName
            binding.salary.text = tdata.salary.toString()
            binding.surname.text = tdata.trainerSurnameX
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TrainerViewHolder {
        return TrainerViewHolder(
            ItemTrainerBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
        )
    }

    override fun onBindViewHolder(holder: TrainerViewHolder, position: Int) {
        holder.bindData(data[position])
    }

    override fun getItemCount(): Int =data.size
}