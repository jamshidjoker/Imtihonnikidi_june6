package com.pdp_dars.imtihonnikidi.retrofit.responces

data class TrainerResponse (
    var id: Int,
    var trainerName: String,
    var salary: Double,
    var trainerSurnameX: String
)