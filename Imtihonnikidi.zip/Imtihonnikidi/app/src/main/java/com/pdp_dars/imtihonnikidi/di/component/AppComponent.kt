package com.pdp_dars.imtihonnikidi.di.component

import android.app.Application
import com.pdp_dars.imtihonnikidi.app.App
import com.pdp_dars.imtihonnikidi.di.module.ActivityBuildersModule
import com.pdp_dars.imtihonnikidi.di.module.AppModule
import dagger.BindsInstance
import dagger.Component
import dagger.android.AndroidInjector
import dagger.android.support.AndroidSupportInjectionModule
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AndroidSupportInjectionModule::class,
        AppModule::class,
        ActivityBuildersModule::class,
//        ActivityBuildersModule::class,
//        ViewModelFactoryModule::class,
    ]
)
interface AppComponent : AndroidInjector<App> {

    @Component.Builder
    interface Builder {
        @BindsInstance
        fun application(application: Application): Builder
        fun build(): AppComponent
    }
}